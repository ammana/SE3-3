package yetToUse;
import java.util.ArrayList;

import basicClasses.Semester;

public class Schedule
{

	private int status;
	ArrayList<Section> sections;
	Semester semester;

	public void generateSchedule() {
		// TODO - implement Schedule.generateSchedule
		throw new UnsupportedOperationException();
	}

	public void testSchedule() {
		// TODO - implement Schedule.testSchedule
		throw new UnsupportedOperationException();
	}

	public void schedule() {
		// TODO - implement Schedule.schedule
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param semester
	 */
	public Schedule(Semester semester) {
		// TODO - implement Schedule.Schedule
		throw new UnsupportedOperationException();
	}

	public ArrayList<Section> getSections() {
		return this.sections;
	}

	public Semester getSemester() {
		return this.semester;
	}

}