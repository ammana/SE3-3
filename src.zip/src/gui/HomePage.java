/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import dataManagement.SystemData;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

/**
 *
 * @author Sandeep
 */
public class HomePage extends javax.swing.JPanel {
    JFrame  panelHolder;
    SystemData systemData;
    
    /**
     * Creates new form HomePage
     * @param panelHolder
     * @param systemData
     */
    public HomePage(JFrame  panelHolder, SystemData systemData) {
        this.panelHolder = panelHolder;
        this.systemData = systemData;        
        initComponents();
        
        JMenuBar menuBar = new JMenuBar();
        panelHolder.setJMenuBar(menuBar);

        JMenu mnMaintain = new JMenu("Maintain");
        menuBar.add(mnMaintain);
        JMenuItem mntmCourse = new JMenuItem("Course");
        mnMaintain.add(mntmCourse);
        mntmCourse.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panelHolder.setTitle("Course Maintainance");
                panelHolder.getContentPane().removeAll();
		panelHolder.getContentPane().add(new CourseMaintainance(panelHolder, systemData));
		panelHolder.getContentPane().revalidate();        
            }
        });
        
        JMenuItem mntmFaculty = new JMenuItem("Faculty");
        mnMaintain.add(mntmFaculty);        
        mntmFaculty.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panelHolder.setTitle("Faculty Maintainance");
                panelHolder.getContentPane().removeAll();
		panelHolder.getContentPane().add(new FacultyMaintainance(panelHolder, systemData));
		panelHolder.getContentPane().revalidate();        
            }
        });
        
        JMenuItem mntmDegree = new JMenuItem("Degree");
        mnMaintain.add(mntmDegree);
        mntmDegree.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panelHolder.setTitle("Degree Maintainance");
                panelHolder.getContentPane().removeAll();
		panelHolder.getContentPane().add(new DegreeMaintainance(panelHolder, systemData));
		panelHolder.getContentPane().revalidate();        
            }
        });
        
        JMenu mnSchedule = new JMenu("Schedule");
        menuBar.add(mnSchedule);
        JMenuItem mntmGenerateSchedule = new JMenuItem("Generate Schedule");
        mnSchedule.add(mntmGenerateSchedule);
        JMenuItem mntmNewMenuItem = new JMenuItem("Test Schedule");
        mnSchedule.add(mntmNewMenuItem);

        JMenu mnReport = new JMenu("Report");
        menuBar.add(mnReport);
        JMenuItem mntmNewMenuItem_1 = new JMenuItem("Schedule Report");
        mnReport.add(mntmNewMenuItem_1);
        JMenuItem mntmNewMenuItem_2 = new JMenuItem("Student Report");
        mnReport.add(mntmNewMenuItem_2);

        JMenu mnImport = new JMenu("Import");
        menuBar.add(mnImport);
        JMenuItem mntmImportStudent = new JMenuItem("Import Student");
        mnImport.add(mntmImportStudent);
        mntmImportStudent.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panelHolder.setTitle("Import Student");
                panelHolder.getContentPane().removeAll();
		panelHolder.getContentPane().add(new ImportStudent(panelHolder, systemData));
		panelHolder.getContentPane().revalidate();        
            }
        });
        
        JMenuItem mntmNewMenuItem_3 = new JMenuItem("Import Student Courses");
        mnImport.add(mntmNewMenuItem_3);
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panelHolder.setTitle("Import Student Courses");
                panelHolder.getContentPane().removeAll();
		panelHolder.getContentPane().add(new ImportStudentCourse(panelHolder, systemData));
		panelHolder.getContentPane().revalidate();        
            }
        });
                
        JMenu mnLogout = new JMenu("Logout");
        menuBar.add(mnLogout);
        JMenuItem mntmCurUserName = new JMenuItem(systemData.getCurrentUser());
        mnLogout.add(mntmCurUserName);
        mntmCurUserName.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panelHolder.setTitle("Login Page");
                //panelHolder.removeAll();
                //panelHolder.setExtendedState(JFrame.MAXIMIZED_BOTH);
                panelHolder.setJMenuBar(null);
                panelHolder.getContentPane().removeAll();
		panelHolder.getContentPane().add(new LogInPanel(panelHolder));
		panelHolder.getContentPane().revalidate();      
            }
        });
                
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setLayout(new java.awt.GridBagLayout());

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Login successful!");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 375;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(125, 10, 0, 10);
        add(jLabel1, gridBagConstraints);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText(" Please go ahead with the task you would like to perform.");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.ipadx = 181;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(11, 10, 160, 10);
        add(jLabel2, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
